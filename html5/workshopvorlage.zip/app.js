require([
    'lib/vendor/jquery',
    'lib/drop',
    'lib/read',
    'lib/canvas',
    'lib/photo'
  ],
  function($, drop, read, canvas, photo){

    // Hier geht's später weiter

});